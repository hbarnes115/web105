function change(picture) {
    document.getElementById("large").src = picture;
}